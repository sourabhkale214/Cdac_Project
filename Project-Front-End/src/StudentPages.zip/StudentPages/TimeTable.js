import React from 'react';
import StudentNavBar from "./StudentNavBar"
//import { useLocation } from 'react-router-dom';


function TimeTable() {
    //const {state}=useLocation()
    return (
          <div>
            <StudentNavBar/>
            {/* <h5>{state.user.data.name}</h5> */}
            <div className='cotainer-fluid'>
       <div className="row justify-content-around align-items-center" style={{height :"98vh" , marginTop:0}}>
       <div className="col-8 p-5 shadow bg-white">
           <center><span><h1>View TimeTable Details</h1></span></center>
           <table className="table table-striped table-secondary">
                 <thead className='table-dark'>
                  <tr>
                  <th>Sr.No</th>
                 <th>Faculty Name</th>
                 <th>Date</th>
                 <th>Start Time</th>
                 <th>End Time</th>
                 <th>Moudule Name</th>
                 <th>Platform</th>
                 <th>Link</th>
                 </tr>
                     </thead>
                 <tbody>
                   <tr>
                   <td>1</td>
                   <td>Shilpi Mam</td>

                   </tr>


                 </tbody>

              </table>
           
            </div>


            </div>

        </div>
          </div>
    );
  }
  
  export default TimeTable;
  