import StudentNavBar from "./StudentNavBar"


function Faculty() {
    return (
          <div>
            <StudentNavBar/>
            <div className='cotainer-fluid'>
       <div className="row justify-content-around align-items-center" style={{height :"98vh" , marginTop:0}}>
       <div className="col-8 p-5 shadow bg-white">
          
           <center><span><h1>Faculty</h1></span></center>
           <table class="table table-striped table-secondary">
                 <thead className="table-dark">
                    <tr>
                  <th>Sr.No</th>
                 <th> FullName</th>
                
                 <th>Mob No</th>
                 <th>Email</th>
               
                 </tr>
                     </thead>
                 <tbody>
                   <tr>
                   <td>1</td>
                   <td>Shilpi Mam</td>

                   </tr>


                 </tbody>

              </table>
           
            </div>


            </div>

        </div>
          </div>
    );
  }
  
  export default Faculty;
  