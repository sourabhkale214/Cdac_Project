import StudentNavBar from "./StudentNavBar"
import React from 'react';

function NoticeBoard() {
    return (
          <div>
            <StudentNavBar/>
            <div className='cotainer-fluid'>
    <div className="row justify-content-around align-items-center" style={{height :"98vh" , marginTop:-25}}>
    
    <div className="col-8 p-5 shadow" style={{backgroundColor : 'white'}}>
    <center><span><h1>View NoticeBoard</h1></span></center>
        <table className="table border table-striped table-secondary" style={{cellspacing:'5'}}>
         
              <tr >
                 <td>This Is Compulsory !!!!</td>
                 </tr>
                 <tr>
                 <td>Publish Date :</td>
                 </tr>
                 <tr>
                 <td>Faculty Name :</td>
              </tr>
              
           </table>
               <br></br>
               <br></br>
           <table className="table border table-striped table-secondary" style={{cellspacing:'5'}}>
              <tr >
                 <td>This Is Compulsory !!!!!</td>
                 </tr>
                 <tr>
                 <td>Publish Date :</td>
                 </tr>
                 <tr>
                 <td>Faculty Name :</td>
              </tr>
           </table>
        
         </div>


         </div>

     </div>
          </div>
    );
  }
  
  export default NoticeBoard;
  